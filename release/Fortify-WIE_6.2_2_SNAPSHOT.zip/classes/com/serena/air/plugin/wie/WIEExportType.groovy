package com.serena.air.plugin.wie

enum WIEExportType {
    FPR,
    Scan,
    XML

    WIEExportType() {}
}


